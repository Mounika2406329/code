package com.example.model;

import jakarta.persistence.*;
import java.util.List;

/**
 * Represents a travel package in the system.
 */
@Entity
public class TravelPackage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long packageId;
    private String title;
    private String description;
    private int duration;
    private double price;

    @ElementCollection
    private List<String> highlights;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Flight> flights;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Hotel> hotels;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Sightseeing> sightseeing;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Itinerary> itinerary;

    @Embedded
    private Offer offer;

	public Long getPackageId() {
		return packageId;
	}

	public void setPackageId(Long packageId) {
		this.packageId = packageId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public List<String> getHighlights() {
		return highlights;
	}

	public void setHighlights(List<String> highlights) {
		this.highlights = highlights;
	}

	public List<Flight> getFlights() {
		return flights;
	}

	public void setFlights(List<Flight> flights) {
		this.flights = flights;
	}

	public List<Hotel> getHotels() {
		return hotels;
	}

	public void setHotels(List<Hotel> hotels) {
		this.hotels = hotels;
	}

	public List<Sightseeing> getSightseeing() {
		return sightseeing;
	}

	public void setSightseeing(List<Sightseeing> sightseeing) {
		this.sightseeing = sightseeing;
	}

	public List<Itinerary> getItinerary() {
		return itinerary;
	}

	public void setItinerary(List<Itinerary> itinerary) {
		this.itinerary = itinerary;
	}

	public Offer getOffer() {
		return offer;
	}

	public void setOffer(Offer offer) {
		this.offer = offer;
	}

    // Getters and Setters
    
}
