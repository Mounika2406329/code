package com.example.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

/**
 * Represents offer details for a travel package.
 */
@Embeddable
public class Offer {

    private String couponCode;

    @Column(name = "offer_description") // Avoids conflict with TravelPackage.description
    private String description;

    private int discountPercentage;
    private boolean active;

    // Getters and Setters
    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(int discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
