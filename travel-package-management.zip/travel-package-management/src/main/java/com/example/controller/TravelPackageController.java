package com.example.controller;

import com.example.service.TravelPackageService;
import com.example.model.TravelPackage;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * REST Controller for managing travel packages.
 */

@RestController
@RequestMapping("/packages")
public class TravelPackageController {

    private final TravelPackageService service;

    public TravelPackageController(TravelPackageService service) {
        this.service = service;
    }

    @GetMapping
    public List<TravelPackage> getAllPackages() {
        return service.getAllPackages();
    }

    @PostMapping
    public TravelPackage createPackage(@RequestBody TravelPackage travelPackage) {
        return service.createPackage(travelPackage);
    }

    @PutMapping("/{id}")
    public TravelPackage updatePackage(@PathVariable Long id, @RequestBody TravelPackage travelPackage) {
        return service.updatePackage(id, travelPackage);
    }

    @DeleteMapping("/{id}")
    public void deletePackage(@PathVariable Long id) {
        service.deletePackage(id);
    }
}

