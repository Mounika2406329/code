package com.example.service;

import com.example.repository.TravelPackageRepository;
import com.example.model.TravelPackage;
import com.example.exception.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Service for managing travel packages.
 */
@Service
public class TravelPackageService {

    private final TravelPackageRepository repository;

    public TravelPackageService(TravelPackageRepository repository) {
        this.repository = repository;
    }

    public List<TravelPackage> getAllPackages() {
        return repository.findAll();
    }

    public TravelPackage createPackage(TravelPackage travelPackage) {
        return repository.save(travelPackage);
    }

    public TravelPackage updatePackage(Long id, TravelPackage updatedPackage) {
        return repository.findById(id)
            .map(existingPackage -> {
                existingPackage.setTitle(updatedPackage.getTitle());
                existingPackage.setDescription(updatedPackage.getDescription());
                existingPackage.setDuration(updatedPackage.getDuration());
                existingPackage.setPrice(updatedPackage.getPrice());
                existingPackage.setHighlights(updatedPackage.getHighlights());
                existingPackage.setFlights(updatedPackage.getFlights());
                existingPackage.setHotels(updatedPackage.getHotels());
                existingPackage.setSightseeing(updatedPackage.getSightseeing());
                existingPackage.setItinerary(updatedPackage.getItinerary());
                existingPackage.setOffer(updatedPackage.getOffer());
                return repository.save(existingPackage);
            })
            .orElseThrow(() -> new ResourceNotFoundException("Package not found with ID: " + id));
    }

    public void deletePackage(Long id) {
        repository.deleteById(id);
    }
}
